package com.nxzry.sudokubot

object Sudoku {
    /** Returns the solved grid (81 ints), or null on a conflict / no solution. */
    fun solve(g: IntArray): IntArray? {
        val b = g.copyOf()
        val rows = IntArray(9); val cols = IntArray(9); val box = IntArray(9)
        for (i in 0 until 81) if (b[i] != 0) {
            val r = i / 9; val c = i % 9; val k = r / 3 * 3 + c / 3; val m = 1 shl b[i]
            if (((rows[r] or cols[c] or box[k]) and m) != 0) return null
            rows[r] = rows[r] or m; cols[c] = cols[c] or m; box[k] = box[k] or m
        }
        fun go(): Boolean {
            var best = -1; var bestFree = 0; var bestN = 10
            for (i in 0 until 81) if (b[i] == 0) {
                val r = i / 9; val c = i % 9; val k = r / 3 * 3 + c / 3
                val free = (rows[r] or cols[c] or box[k]).inv() and 0x3FE
                val n = Integer.bitCount(free)
                if (n < bestN) { bestN = n; best = i; bestFree = free; if (n <= 1) break }
            }
            if (best < 0) return true
            if (bestN == 0) return false
            val r = best / 9; val c = best % 9; val k = r / 3 * 3 + c / 3
            for (d in 1..9) {
                val m = 1 shl d
                if ((bestFree and m) == 0) continue
                b[best] = d; rows[r] = rows[r] or m; cols[c] = cols[c] or m; box[k] = box[k] or m
                if (go()) return true
                b[best] = 0; rows[r] = rows[r] and m.inv(); cols[c] = cols[c] and m.inv(); box[k] = box[k] and m.inv()
            }
            return false
        }
        return if (go()) b else null
    }
}
