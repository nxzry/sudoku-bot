package com.nxzry.sudokubot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class BotService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var bar: LinearLayout? = null
    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cal", MODE_PRIVATE) }
    private var statusView: TextView? = null
    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBar()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        try { bar?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    private val hideStatus = Runnable { statusView?.visibility = View.GONE }
    private fun say(s: String) {
        statusView?.let {
            it.text = s; it.visibility = View.VISIBLE
            h.removeCallbacks(hideStatus); h.postDelayed(hideStatus, 15000)
        }
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }
    private fun barOn(on: Boolean) { bar?.visibility = if (on) View.VISIBLE else View.GONE }

    private fun showBar() {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(8, 8, 8, 8)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 12f; setOnClickListener { f() }
        }
        l.addView(btn("SOLVE") { solveNow() })
        l.addView(btn("SETUP") { startSetup() })
        val lp = WindowManager.LayoutParams(
            W, W, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 200 }
        wm.addView(l, lp)
        bar = l
        val sv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f
            setBackgroundColor(0xDD000000.toInt()); setPadding(20, 14, 20, 14)
            visibility = View.GONE
        }
        wm.addView(sv, WindowManager.LayoutParams(
            W, W, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 60 })
        statusView = sv
        say("Sudoku Bot ready.")
    }

    // ---------- one-time setup: 4 taps ----------
    private fun startSetup() {
        barOn(false)
        val steps = listOf(
            "SETUP 1/4: tap the TOP-LEFT corner of the sudoku grid",
            "SETUP 2/4: tap the BOTTOM-RIGHT corner of the grid",
            "SETUP 3/4: tap the centre of number key 1",
            "SETUP 4/4: tap the centre of number key 9"
        )
        val pts = ArrayList<FloatArray>()
        val tv = TextView(this).apply {
            text = steps[0]; setTextColor(Color.WHITE); textSize = 18f
            setBackgroundColor(0xCC000000.toInt()); setPadding(24, 24, 24, 24)
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0x22000000)
        root.addView(tv, FrameLayout.LayoutParams(M, W, Gravity.TOP).apply { topMargin = 150 })
        root.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP) {
                pts.add(floatArrayOf(ev.rawX, ev.rawY))
                if (pts.size < 4) tv.text = steps[pts.size] else {
                    wm.removeView(root)
                    prefs.edit()
                        .putFloat("gx1", pts[0][0]).putFloat("gy1", pts[0][1])
                        .putFloat("gx2", pts[1][0]).putFloat("gy2", pts[1][1])
                        .putFloat("kx1", pts[2][0]).putFloat("kx9", pts[3][0])
                        .putFloat("ky", (pts[2][1] + pts[3][1]) / 2f)
                        .apply()
                    barOn(true)
                    say("Setup saved. Turn Pencil OFF and tap SOLVE.")
                }
            }
            true
        }
        wm.addView(root, WindowManager.LayoutParams(
            M, M, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ))
    }

    // ---------- solve ----------
    private fun solveNow() {
        if (!prefs.contains("gx1")) { say("Tap SETUP first."); return }
        say("SOLVE pressed. Capturing screen in 1 second...")
        h.postDelayed({
            statusView?.visibility = View.GONE
            barOn(false)
            h.postDelayed({
                try {
                    takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                            try {
                                val hb = r.hardwareBuffer
                                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                                hb.close()
                                if (bmp == null) fail("Screenshot came back empty.") else {
                                    say("Got screenshot ${bmp.width}x${bmp.height}. Reading digits...")
                                    readGrid(bmp)
                                }
                            } catch (e: Throwable) { fail("Screenshot error: $e") }
                        }
                        override fun onFailure(code: Int) = fail("Screenshot blocked (code $code).")
                    })
                } catch (e: Throwable) { fail("takeScreenshot error: $e") }
            }, 350)
        }, 1000)
    }

    private fun fail(m: String) { barOn(true); say(m) }

    private fun digitOf(ch: Char): Int = when (ch) {
        in '1'..'9' -> ch - '0'
        'l', 'I', '|' -> 1
        'S' -> 5
        'B' -> 8
        'g' -> 9
        'G' -> 6
        else -> 0
    }

    private fun readGrid(bmp: Bitmap) {
        val gx1 = prefs.getFloat("gx1", 0f); val gy1 = prefs.getFloat("gy1", 0f)
        val gx2 = prefs.getFloat("gx2", 0f); val gy2 = prefs.getFloat("gy2", 0f)
        val cw = (gx2 - gx1) / 9f; val ch = (gy2 - gy1) / 9f
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t ->
                val g = IntArray(81)
                for (b in t.textBlocks) for (l in b.lines) for (e in l.elements) {
                    val syms = e.symbols
                    val items = if (syms.isNotEmpty()) syms.map { it.text to it.boundingBox }
                                else listOf(e.text to e.boundingBox)
                    for ((s, box) in items) {
                        if (box == null || s.length != 1) continue
                        val d = digitOf(s[0])
                        if (d == 0 || box.height() < 0.38f * ch) continue // skip small pencil marks
                        val cx = box.exactCenterX(); val cy = box.exactCenterY()
                        if (cx < gx1 || cy < gy1 || cx >= gx2 || cy >= gy2) continue
                        g[((cy - gy1) / ch).toInt() * 9 + ((cx - gx1) / cw).toInt()] = d
                    }
                }
                rec.close()
                val n = g.count { it != 0 }
                val dump = g.toList().chunked(9).joinToString("\n") { row ->
                    row.joinToString(" ") { if (it == 0) "." else it.toString() }
                }
                val sol = if (n >= 17) Sudoku.solve(g) else null
                if (sol == null) { fail("Couldn't read the grid cleanly ($n digits). I saw:\n$dump"); return@addOnSuccessListener }
                val taps = ArrayList<FloatArray>()
                val kx1 = prefs.getFloat("kx1", 0f); val kx9 = prefs.getFloat("kx9", 0f); val ky = prefs.getFloat("ky", 0f)
                for (i in 0 until 81) if (g[i] == 0) {
                    taps.add(floatArrayOf(gx1 + (i % 9 + 0.5f) * cw, gy1 + (i / 9 + 0.5f) * ch))
                    taps.add(floatArrayOf(kx1 + (sol[i] - 1) * (kx9 - kx1) / 8f, ky))
                }
                say("Read $n digits. Playing ${taps.size / 2} cells...")
                play(taps, 0)
            }
            .addOnFailureListener { fail("Text reader failed: ${it.message}") }
    }

    private fun play(taps: List<FloatArray>, i: Int) {
        if (i >= taps.size) { barOn(true); say("Done."); return }
        val p = Path().apply { moveTo(taps[i][0], taps[i][1]) }
        val gd = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 40)).build()
        val next = { h.postDelayed({ play(taps, i + 1) }, 90) }
        val ok = dispatchGesture(gd, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { next() }
            override fun onCancelled(g: GestureDescription?) { next() }
        }, null)
        if (!ok) fail("Tap failed.")
    }
}
