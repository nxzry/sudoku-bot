package com.nxzry.sudokubot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class BotService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var bar: LinearLayout? = null
    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cal", MODE_PRIVATE) }
    private var statusView: TextView? = null
    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBar()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        try { bar?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    private val hideStatus = Runnable { statusView?.visibility = View.GONE }
    private fun say(s: String) {
        statusView?.let {
            it.text = s; it.visibility = View.VISIBLE
            h.removeCallbacks(hideStatus); h.postDelayed(hideStatus, 15000)
        }
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }
    private var guide: View? = null
    private fun showGuide(x1: Float, y1: Float, x2: Float, y2: Float) {
        guide?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val v = object : View(this) {
            override fun onDraw(c: Canvas) {
                val p = Paint().apply { color = Color.RED; strokeWidth = 3f }
                val loc = IntArray(2); getLocationOnScreen(loc)
                c.translate(-loc[0].toFloat(), -loc[1].toFloat())
                for (i in 0..9) {
                    val x = x1 + (x2 - x1) * i / 9f; c.drawLine(x, y1, x, y2, p)
                    val y = y1 + (y2 - y1) * i / 9f; c.drawLine(x1, y, x2, y, p)
                }
            }
        }
        wm.addView(v, WindowManager.LayoutParams(
            M, M, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ))
        guide = v
        h.postDelayed({ try { wm.removeView(v) } catch (_: Exception) {}; if (guide === v) guide = null }, 10000)
    }
    private fun barOn(on: Boolean) { bar?.visibility = if (on) View.VISIBLE else View.GONE }

    private fun showBar() {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(8, 8, 8, 8)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 12f; setOnClickListener { f() }
        }
        l.addView(btn("SOLVE") { solveNow() })
        l.addView(btn("SETUP") { startSetup() })
        val lp = WindowManager.LayoutParams(
            W, W, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 200 }
        wm.addView(l, lp)
        bar = l
        val sv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f
            setBackgroundColor(0xDD000000.toInt()); setPadding(20, 14, 20, 14)
            visibility = View.GONE
        }
        wm.addView(sv, WindowManager.LayoutParams(
            W, W, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 60 })
        statusView = sv
        say("Sudoku Bot ready.")
    }

    // ---------- one-time setup: 4 taps ----------
    private fun startSetup() {
        barOn(false)
        val steps = listOf(
            "SETUP 1/4: tap the TOP-LEFT corner of the sudoku grid",
            "SETUP 2/4: tap the BOTTOM-RIGHT corner of the grid",
            "SETUP 3/4: tap the centre of number key 1",
            "SETUP 4/4: tap the centre of number key 9"
        )
        val pts = ArrayList<FloatArray>()
        val tv = TextView(this).apply {
            text = steps[0]; setTextColor(Color.WHITE); textSize = 18f
            setBackgroundColor(0xCC000000.toInt()); setPadding(24, 24, 24, 24)
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0x22000000)
        root.addView(tv, FrameLayout.LayoutParams(M, W, Gravity.TOP).apply { topMargin = 150 })
        root.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP) {
                pts.add(floatArrayOf(ev.rawX, ev.rawY))
                if (pts.size < 4) tv.text = steps[pts.size] else {
                    wm.removeView(root)
                    prefs.edit()
                        .putFloat("gx1", pts[0][0]).putFloat("gy1", pts[0][1])
                        .putFloat("gx2", pts[1][0]).putFloat("gy2", pts[1][1])
                        .putFloat("kx1", pts[2][0]).putFloat("kx9", pts[3][0])
                        .putFloat("ky", (pts[2][1] + pts[3][1]) / 2f)
                        .apply()
                    barOn(true)
                    showGuide(pts[0][0], pts[0][1], pts[1][0], pts[1][1])
                    say("Setup saved. The red lines should sit exactly on the game grid. If not, tap SETUP again.")
                }
            }
            true
        }
        wm.addView(root, WindowManager.LayoutParams(
            M, M, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ))
    }

    // ---------- solve ----------
    private fun solveNow() {
        say("SOLVE pressed. Capturing screen in 1 second...")
        h.postDelayed({
            statusView?.visibility = View.GONE
            barOn(false)
            h.postDelayed({
                try {
                    takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                            try {
                                val hb = r.hardwareBuffer
                                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                                hb.close()
                                if (bmp == null) fail("Screenshot came back empty.") else {
                                    say("Got screenshot ${bmp.width}x${bmp.height}. Reading digits...")
                                    readGrid(bmp)
                                }
                            } catch (e: Throwable) { fail("Screenshot error: $e") }
                        }
                        override fun onFailure(code: Int) = fail("Screenshot blocked (code $code).")
                    })
                } catch (e: Throwable) { fail("takeScreenshot error: $e") }
            }, 350)
        }, 1000)
    }

    private fun fail(m: String) { barOn(true); say(m) }

    private fun digitOf(ch: Char): Int = when (ch) {
        in '1'..'9' -> ch - '0'
        'l', 'I' -> 1
        'S' -> 5
        'B' -> 8
        'g' -> 9
        'G' -> 6
        'A' -> 4
        'Z', 'z' -> 2
        'T' -> 7
        'q' -> 9
        else -> 0
    }

    // Redraws the grid as clean black digits on white, cell by cell, so colours/highlights don't confuse the reader.
    private fun clean(bmp: Bitmap, gx1: Float, gy1: Float, cw: Float, ch: Float, S: Int): Bitmap {
        val out = Bitmap.createBitmap(9 * S, 9 * S, Bitmap.Config.ARGB_8888)
        val buf = IntArray(S * S)
        val spots = arrayOf(
            floatArrayOf(.1f, .1f), floatArrayOf(.9f, .1f), floatArrayOf(.1f, .9f), floatArrayOf(.9f, .9f),
            floatArrayOf(.5f, .1f), floatArrayOf(.5f, .9f), floatArrayOf(.1f, .5f), floatArrayOf(.9f, .5f)
        )
        fun pix(x: Float, y: Float) = bmp.getPixel(x.toInt().coerceIn(0, bmp.width - 1), y.toInt().coerceIn(0, bmp.height - 1))
        for (r in 0 until 9) for (c in 0 until 9) {
            val x0 = gx1 + c * cw; val y0 = gy1 + r * ch
            val samples = spots.map { pix(x0 + it[0] * cw, y0 + it[1] * ch) }
            fun med(sh: Int) = samples.map { (it shr sh) and 255 }.sorted()[4]
            val br = med(16); val bg = med(8); val bb = med(0)
            for (oy in 0 until S) for (ox in 0 until S) {
                val fx = (ox + 0.5f) / S; val fy = (oy + 0.5f) / S
                var ink = false
                if (fx in 0.1f..0.9f && fy in 0.1f..0.9f) {
                    val p = pix(x0 + fx * cw, y0 + fy * ch)
                    val d = Math.abs(((p shr 16) and 255) - br) + Math.abs(((p shr 8) and 255) - bg) + Math.abs((p and 255) - bb)
                    ink = d > 110
                }
                buf[oy * S + ox] = if (ink) Color.BLACK else Color.WHITE
            }
            out.setPixels(buf, 0, S, c * S, r * S, S, S)
        }
        return out
    }

    private fun found(t: com.google.mlkit.vision.text.Text): List<Pair<Int, android.graphics.Rect>> {
        val out = ArrayList<Pair<Int, android.graphics.Rect>>()
        for (b in t.textBlocks) for (l in b.lines) for (e in l.elements) {
            val syms = e.symbols
            val items = if (syms.isNotEmpty()) syms.map { it.text to it.boundingBox } else listOf(e.text to e.boundingBox)
            for ((s, box) in items) {
                if (box == null || s.length != 1) continue
                val d = digitOf(s[0])
                if (d != 0) out.add(d to box)
            }
        }
        return out
    }

    private fun centerInk(img: Bitmap, i: Int, S: Int): Float {
        val x0 = (i % 9) * S; val y0 = (i / 9) * S
        var n = 0; var tot = 0
        for (y in y0 + (S * 0.25f).toInt() until y0 + (S * 0.75f).toInt())
            for (x in x0 + (S * 0.3f).toInt() until x0 + (S * 0.7f).toInt()) {
                tot++; if (img.getPixel(x, y) == Color.BLACK) n++
            }
        return n.toFloat() / tot
    }

    // Cuts the biggest ink blob out of a cell and shrinks it to a 20x28 picture, or null if the cell has no big digit.
    private fun glyph(img: Bitmap, i: Int, S: Int): FloatArray? {
        val px = IntArray(S * S)
        img.getPixels(px, 0, S, (i % 9) * S, (i / 9) * S, S, S)
        val lab = IntArray(S * S); val q = IntArray(S * S)
        var nl = 0; var bestLab = 0; var bestArea = 0
        var bx0 = 0; var by0 = 0; var bx1 = 0; var by1 = 0
        for (st in 0 until S * S) {
            if (px[st] != Color.BLACK || lab[st] != 0) continue
            nl++
            var qh = 0; var qt = 0
            q[qt++] = st; lab[st] = nl
            var x0 = S; var y0 = S; var x1 = 0; var y1 = 0; var area = 0
            while (qh < qt) {
                val c = q[qh++]; val cx = c % S; val cy = c / S
                area++
                if (cx < x0) x0 = cx
                if (cx > x1) x1 = cx
                if (cy < y0) y0 = cy
                if (cy > y1) y1 = cy
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = cx + dx; val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= S || ny >= S) continue
                    val ni = ny * S + nx
                    if (px[ni] == Color.BLACK && lab[ni] == 0) { lab[ni] = nl; q[qt++] = ni }
                }
            }
            val hh = y1 - y0 + 1
            val ccx = (x0 + x1) / 2f / S; val ccy = (y0 + y1) / 2f / S
            if (hh >= 0.38f * S && ccx in 0.2f..0.8f && ccy in 0.2f..0.8f && area > bestArea) {
                bestArea = area; bestLab = nl; bx0 = x0; by0 = y0; bx1 = x1; by1 = y1
            }
        }
        if (bestLab == 0) return null
        val w = (bx1 - bx0 + 1).toFloat(); val hg = (by1 - by0 + 1).toFloat()
        val sc = minOf(28f / hg, 20f / w)
        val offx = (20f - w * sc) / 2f; val offy = (28f - hg * sc) / 2f
        val out = FloatArray(560)
        for (ty in 0 until 28) for (tx in 0 until 20) {
            var c = 0
            for (a in 0..2) for (b in 0..2) {
                val fx = (tx + (b + 0.5f) / 3f - offx) / sc + bx0
                val fy = (ty + (a + 0.5f) / 3f - offy) / sc + by0
                if (fx >= bx0.toFloat() && fy >= by0.toFloat() && fx < bx1 + 1f && fy < by1 + 1f &&
                    lab[fy.toInt() * S + fx.toInt()] == bestLab) c++
            }
            out[ty * 20 + tx] = c / 9f
        }
        return out
    }

    // Uses the digits the text reader got right as examples, and re-labels every digit shape by which example it looks most like.
    private fun fixLabels(g: IntArray, gl: Array<FloatArray?>): Int {
        val cent = Array(10) { FloatArray(560) }
        val cnt = IntArray(10)
        fun dist(a: FloatArray, b: FloatArray): Float { var s = 0f; for (k in 0 until 560) { val d = a[k] - b[k]; s += d * d }; return s }
        fun build(l: IntArray) {
            for (d in 1..9) { java.util.Arrays.fill(cent[d], 0f); cnt[d] = 0 }
            for (i in 0 until 81) { val v = gl[i]; if (v != null && l[i] in 1..9) { cnt[l[i]]++; for (k in 0 until 560) cent[l[i]][k] += v[k] } }
            for (d in 1..9) if (cnt[d] > 0) for (k in 0 until 560) cent[d][k] /= cnt[d]
        }
        fun nearest(v: FloatArray): Pair<Int, Float> {
            var bd = 0; var bs = Float.MAX_VALUE
            for (d in 1..9) if (cnt[d] > 0) { val sc = dist(v, cent[d]); if (sc < bs) { bs = sc; bd = d } }
            return bd to bs
        }
        var lab = g.copyOf()
        repeat(2) {
            build(lab)
            val nl = IntArray(81)
            for (i in 0 until 81) { val v = gl[i]; nl[i] = if (v != null) nearest(v).first else 0 }
            lab = nl
        }
        build(lab)
        var tot = 0f; var n = 0
        for (i in 0 until 81) { val v = gl[i]; if (v != null && lab[i] > 0) { tot += dist(v, cent[lab[i]]); n++ } }
        val thr = 3f * tot / maxOf(n, 1)
        var bad = 0
        for (i in 0 until 81) {
            val v = gl[i] ?: continue
            val (d, sc) = nearest(v)
            if (sc <= thr) g[i] = d else if (g[i] == 0) bad++
        }
        return bad
    }

    private class Cal(val gx: Float, val gy: Float, val p: Float, val kx1: Float, val kx9: Float, val ky: Float)
    private class Ax(val n: IntArray, val k: Int, val cnt: Int)

    private fun med(l: List<Float>): Float = l.sorted()[l.size / 2]

    // Finds the grid and the number keys purely from where big digits sit on the screenshot.
    private fun locate(t: com.google.mlkit.vision.text.Text, W: Int): Cal? {
        val minH = 0.035f * W; val maxH = 0.09f * W
        val ds = ArrayList<FloatArray>() // [digit, centreX, centreY]
        for ((d, box) in found(t)) {
            val hh = box.height().toFloat()
            if (hh in minH..maxH) ds.add(floatArrayOf(d.toFloat(), box.exactCenterX(), box.exactCenterY()))
        }
        if (ds.size < 12) return null
        // cell pitch = spacing at which digit centres line up best
        var bestP = 0f; var bestR = -1.0
        var pp = 0.06f * W
        while (pp <= 0.125f * W) {
            var a = 0.0; var b = 0.0; var c = 0.0; var d = 0.0
            for (v in ds) {
                val ax = 2 * Math.PI * v[1] / pp; val ay = 2 * Math.PI * v[2] / pp
                a += Math.cos(ax); b += Math.sin(ax); c += Math.cos(ay); d += Math.sin(ay)
            }
            val r = (Math.hypot(a, b) + Math.hypot(c, d)) / ds.size
            if (r > bestR) { bestR = r; bestP = pp }
            pp += 0.2f
        }
        fun axis(sel: Int): Ax {
            var sc = 0.0; var ss = 0.0
            for (v in ds) { val a = 2 * Math.PI * v[sel] / bestP; sc += Math.cos(a); ss += Math.sin(a) }
            var c0 = (Math.atan2(ss, sc) / (2 * Math.PI) * bestP).toFloat()
            if (c0 < 0) c0 += bestP
            val n = IntArray(ds.size) { Math.round((ds[it][sel] - c0) / bestP) }
            var bk = n.min(); var bc = -1
            for (k in n.min()..n.max()) {
                val cnt = n.count { it >= k && it <= k + 8 }
                if (cnt > bc) { bc = cnt; bk = k }
            }
            return Ax(n, bk, bc)
        }
        val axx = axis(1); val ayy = axis(2)
        if (axx.cnt < 10 || ayy.cnt < 10) return null
        fun slope(sel: Int, a: Ax): Float? {
            val xs = ArrayList<Float>(); val ns = ArrayList<Float>()
            for (i in ds.indices) if (a.n[i] >= a.k && a.n[i] <= a.k + 8) { ns.add((a.n[i] - a.k).toFloat()); xs.add(ds[i][sel]) }
            val mn = ns.average().toFloat(); val mx = xs.average().toFloat()
            var num = 0f; var den = 0f
            for (i in ns.indices) { num += (ns[i] - mn) * (xs[i] - mx); den += (ns[i] - mn) * (ns[i] - mn) }
            return if (den < 4f) null else num / den
        }
        val sl = listOfNotNull(slope(1, axx), slope(2, ayy)).filter { Math.abs(it - bestP) < 0.03f * bestP }
        val p = if (sl.isEmpty()) bestP else sl.average().toFloat()
        fun origin(sel: Int, a: Ax): Float {
            var s = 0f; var c = 0
            for (i in ds.indices) if (a.n[i] >= a.k && a.n[i] <= a.k + 8) { s += ds[i][sel] - (a.n[i] - a.k) * p; c++ }
            return s / c
        }
        val gx = origin(1, axx) - p / 2; val gy = origin(2, ayy) - p / 2
        if (gx < -p || gx + 9 * p > W + p) return null
        // number keys: a row of big digits below the grid
        val bottom = gy + 9 * p
        val pad = ds.filter { it[2] > bottom + 0.3f * p }
        var kx1 = Float.NaN; var kx9 = Float.NaN; var ky = Float.NaN
        if (pad.size >= 2) {
            var bg: List<FloatArray> = emptyList()
            for (v in pad) { val g = pad.filter { Math.abs(it[2] - v[2]) < 0.3f * p }; if (g.size > bg.size) bg = g }
            val steps = ArrayList<Float>()
            for (i in bg.indices) for (j in i + 1 until bg.size) {
                val dd = bg[j][0] - bg[i][0]
                if (dd != 0f) { val st = (bg[j][1] - bg[i][1]) / dd; if (st > 0) steps.add(st) }
            }
            if (steps.isNotEmpty()) {
                val st = med(steps)
                kx1 = med(bg.map { it[1] - (it[0] - 1) * st }); kx9 = kx1 + 8 * st; ky = med(bg.map { it[2] })
            }
        }
        return Cal(gx, gy, p, kx1, kx9, ky)
    }

    private fun readGrid(bmp: Bitmap) {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val bd = wm.maximumWindowMetrics.bounds
        val sx = bmp.width.toFloat() / bd.width(); val sy = bmp.height.toFloat() / bd.height()
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t0 ->
                val cal = locate(t0, bmp.width)
                if (cal == null) {
                    rec.close()
                    fail("Couldn't find the sudoku grid. Open a puzzle so the whole grid and the number keys are visible, then try again.")
                    return@addOnSuccessListener
                }
                val S = 120
                val img = clean(bmp, cal.gx, cal.gy, cal.p, cal.p, S)
                rec.process(InputImage.fromBitmap(img, 0))
                    .addOnSuccessListener { t ->
                        val g = IntArray(81)
                        for ((d, box) in found(t)) {
                            if (box.height() < 0.38f * S) continue // skip small pencil marks
                            val cx = box.exactCenterX(); val cy = box.exactCenterY()
                            if (cx < 0 || cy < 0 || cx >= 9 * S || cy >= 9 * S) continue
                            val fx = (cx % S) / S; val fy = (cy % S) / S
                            if (fx < 0.2f || fx > 0.8f || fy < 0.2f || fy > 0.8f) continue
                            g[(cy / S).toInt() * 9 + (cx / S).toInt()] = d
                        }
                        val gl = Array<FloatArray?>(81) { glyph(img, it, S) }
                        val todo = (0 until 81).filter { g[it] == 0 && gl[it] != null }
                        say("Grid found. First pass read ${g.count { it != 0 }} digits. Rechecking ${todo.size} cells...")
                        refine(rec, img, S, g, todo, 0) { finish(rec, g, gl, cal, sx, sy) }
                    }
                    .addOnFailureListener { rec.close(); fail("Text reader failed: ${it.message}") }
            }
            .addOnFailureListener { rec.close(); fail("Text reader failed: ${it.message}") }
    }

    private fun refine(rec: com.google.mlkit.vision.text.TextRecognizer, img: Bitmap, S: Int, g: IntArray,
                       todo: List<Int>, k: Int, done: () -> Unit) {
        if (k >= todo.size) { done(); return }
        val i = todo[k]
        val pad = Bitmap.createBitmap(S * 2, S * 2, Bitmap.Config.ARGB_8888)
        val cv = Canvas(pad); cv.drawColor(Color.WHITE)
        cv.drawBitmap(Bitmap.createBitmap(img, (i % 9) * S, (i / 9) * S, S, S), S / 2f, S / 2f, null)
        rec.process(InputImage.fromBitmap(pad, 0))
            .addOnSuccessListener { t ->
                var bestH = 0
                for ((d, box) in found(t)) {
                    val fx = (box.exactCenterX() - S / 2f) / S; val fy = (box.exactCenterY() - S / 2f) / S
                    if (fx < 0.2f || fx > 0.8f || fy < 0.2f || fy > 0.8f) continue
                    if (box.height() >= 0.38f * S && box.height() > bestH) { bestH = box.height(); g[i] = d }
                }
                refine(rec, img, S, g, todo, k + 1, done)
            }
            .addOnFailureListener { refine(rec, img, S, g, todo, k + 1, done) }
    }

    private fun finish(rec: com.google.mlkit.vision.text.TextRecognizer, g: IntArray, gl: Array<FloatArray?>, cal: Cal, sx: Float, sy: Float) {
        rec.close()
        val p = cal.p
        showGuide(cal.gx / sx, cal.gy / sy, (cal.gx + 9 * p) / sx, (cal.gy + 9 * p) / sy)
        val before = g.copyOf()
        val bad = fixLabels(g, gl)
        val fixed = (0 until 81).count { before[it] != g[it] }
        val n = g.count { it != 0 }
        val dump = g.toList().chunked(9).joinToString("\n") { row ->
            row.joinToString(" ") { if (it == 0) "." else it.toString() }
        }
        if (bad > 0) { fail("$bad cells I couldn't tell apart ($n digits read). I saw:\n$dump"); return }
        val sol = if (n >= 17) Sudoku.solve(g) else null
        if (sol == null) { fail("Couldn't read the grid cleanly ($n digits). I saw:\n$dump"); return }
        val kx1: Float; val kx9: Float; val ky: Float
        if (!cal.kx1.isNaN()) { kx1 = cal.kx1 / sx; kx9 = cal.kx9 / sx; ky = cal.ky / sy }
        else if (prefs.contains("kx1")) { kx1 = prefs.getFloat("kx1", 0f); kx9 = prefs.getFloat("kx9", 0f); ky = prefs.getFloat("ky", 0f) }
        else { fail("Couldn't find the number keys. Make sure they are visible, or tap SETUP once."); return }
        val taps = ArrayList<FloatArray>()
        for (i in 0 until 81) if (g[i] == 0) {
            taps.add(floatArrayOf((cal.gx + (i % 9 + 0.5f) * p) / sx, (cal.gy + (i / 9 + 0.5f) * p) / sy))
            taps.add(floatArrayOf(kx1 + (sol[i] - 1) * (kx9 - kx1) / 8f, ky))
        }
        say("Read $n digits (fixed $fixed):\n$dump\nPlaying ${taps.size / 2} cells in 6 seconds...")
        h.postDelayed({ play(taps, 0) }, 6000)
    }

    private fun play(taps: List<FloatArray>, i: Int) {
        if (i >= taps.size) { barOn(true); say("Done."); return }
        val p = Path().apply { moveTo(taps[i][0], taps[i][1]) }
        val gd = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 40)).build()
        val next = { h.postDelayed({ play(taps, i + 1) }, 90) }
        val ok = dispatchGesture(gd, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { next() }
            override fun onCancelled(g: GestureDescription?) { next() }
        }, null)
        if (!ok) fail("Tap failed.")
    }
}
