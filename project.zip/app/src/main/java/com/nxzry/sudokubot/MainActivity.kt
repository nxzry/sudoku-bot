package com.nxzry.sudokubot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        l.addView(TextView(this).apply {
            textSize = 16f
            text = "SUDOKU BOT\n\n" +
                "1. If Android blocks the next step: Settings > Apps > Sudoku Bot > three dots > Allow restricted settings.\n\n" +
                "2. Tap the button below, open Installed apps, tap Sudoku Bot and turn it ON.\n\n" +
                "3. Open the sudoku game on a puzzle with the whole grid and number keys visible. Turn Pencil OFF. A SOLVE / SETUP bar appears at the top right.\n\n" +
                "4. Tap SOLVE. It finds the grid and keys by itself. (SETUP is only a manual backup.)\n\n" +
                "To stop it, turn the accessibility service off."
        })
        l.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
